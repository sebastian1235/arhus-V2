create view cotizacion as
  select
    `arhus`.`ap_cotizacion`.`sol_cot`         AS `sol_cot`,
    `arhus`.`ap_cotizacion`.`consecutivo_cot` AS `consecutivo_cot`,
    `arhus`.`ap_cotizacion`.`estrato_cot`     AS `estrato_cot`,
    `arhus`.`ap_solicitud`.`asignacion_sol`   AS `asignacion_sol`,
    `arhus`.`ap_solicitud`.`asesor_sol`       AS `asesor_sol`,
    `arhus`.`ap_solicitud`.`nombre_sol`       AS `nombre_sol`,
    `arhus`.`ap_solicitud`.`servicio_sol`     AS `servicio_sol`
  from (`arhus`.`ap_cotizacion`
    join `arhus`.`ap_solicitud`);

