create view demanda_sin_sol as
  select
    `arhus`.`demanda`.`origen_dem`                                                        AS `origen_dem`,
    concat('TC ', `arhus`.`demanda`.`tipo_cliente_dem`, '- Uso ', `arhus`.`demanda`.`uso`, '-',
           `arhus`.`demanda`.`fecha_trab_dem`, '- Estrato ', `arhus`.`demanda`.`estrato`) AS `observacion`,
    `arhus`.`demanda`.`fecha_llamada`                                                     AS `fecha_llamada`,
    `arhus`.`demanda`.`cod_dem`                                                           AS `cod_dem`,
    `arhus`.`demanda`.`poliza_dem`                                                        AS `poliza_dem`,
    `arhus`.`demanda`.`usuario_captura`                                                   AS `usuario_captura`,
    `arhus`.`demanda`.`campana_demanda`                                                   AS `campana_demanda`,
    `arhus`.`demanda`.`chip_natural`                                                      AS `chip_natural`,
    `arhus`.`demanda`.`estado_predio`                                                     AS `estado_predio`,
    `arhus`.`demanda`.`tipo_predio`                                                       AS `tipo_predio`,
    `arhus`.`demanda`.`mecado`                                                            AS `mecado`,
    `arhus`.`demanda`.`nombre_cliente`                                                    AS `nombre_cliente`,
    `arhus`.`demanda`.`num_doc`                                                           AS `num_doc`,
    `arhus`.`demanda`.`direccion`                                                         AS `direccion`,
    `arhus`.`demanda`.`municipio`                                                         AS `municipio`,
    `arhus`.`demanda`.`telefono`                                                          AS `telefono`,
    `arhus`.`demanda`.`cod_trabajo_original`                                              AS `cod_trabajo_original`,
    `arhus`.`demanda`.`cod_ult_visit`                                                     AS `cod_ult_visit`,
    `arhus`.`demanda`.`res_ult_vis`                                                       AS `res_ult_vis`,
    `arhus`.`demanda`.`fecha_ult_visita`                                                  AS `fecha_ult_visita`,
    `arhus`.`demanda`.`usu_asig_primer_trab`                                              AS `usu_asig_primer_trab`,
    `arhus`.`demanda`.`fecha_prim_visit`                                                  AS `fecha_prim_visit`,
    `arhus`.`demanda`.`respuesta_pv`                                                      AS `respuesta_pv`,
    `arhus`.`demanda`.`fecha_cap_primera_visita`                                          AS `fecha_cap_primera_visita`,
    `arhus`.`demanda`.`cod_contratista`                                                   AS `cod_contratista`,
    `arhus`.`demanda`.`nom_cont`                                                          AS `nom_cont`,
    `arhus`.`demanda`.`distrito`                                                          AS `distrito`,
    `arhus`.`demanda`.`malla`                                                             AS `malla`,
    `arhus`.`demanda`.`sector`                                                            AS `sector`,
    `arhus`.`demanda`.`descr_estado_dem`                                                  AS `descr_estado_dem`,
    `arhus`.`demanda`.`estrato`                                                           AS `estrato`,
    `arhus`.`demanda`.`clase_dem`                                                         AS `clase_dem`
  from (`arhus`.`demanda`
    left join `arhus`.`ap_solicitud` on ((`arhus`.`demanda`.`cod_dem` = `arhus`.`ap_solicitud`.`demanda_sol`)))
  where isnull(`arhus`.`ap_solicitud`.`demanda_sol`);

