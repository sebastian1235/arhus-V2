create view vista_cotizacion as
  select
    `arhus`.`ap_cotizacion`.`id_cot`           AS `id_cot`,
    `arhus`.`ap_cotizacion`.`sol_cot`          AS `sol_cot`,
    `arhus`.`ap_cotizacion`.`consecutivo_cot`  AS `consecutivo_cot`,
    `arhus`.`ap_cotizacion`.`estrato_cot`      AS `estrato_cot`,
    `arhus`.`ap_cotizacion`.`fecha_nac_cot`    AS `fecha_nac_cot`,
    `arhus`.`ap_cotizacion`.`forma_pago_cot`   AS `forma_pago_cot`,
    `arhus`.`ap_cotizacion`.`campana_cot`      AS `campana_cot`,
    `arhus`.`siax_campana`.`nombre_campana`    AS `nombre_campana`,
    `arhus`.`ap_cotizacion`.`tipo_cliente_cot` AS `tipo_cliente_cot`,
    `arhus`.`ap_cotizacion`.`fecha_cot`        AS `fecha_cot`,
    `arhus`.`ap_cotizacion`.`v_total_cot`      AS `v_total_cot`,
    `arhus`.`ap_cotizacion`.`v_contado_cot`    AS `v_contado_cot`,
    `arhus`.`ap_cotizacion`.`estado_cot`       AS `estado_cot`,
    `arhus`.`ap_cotizacion`.`obs_cot`          AS `obs_cot`,
    `arhus`.`ap_cotizacion`.`pagare_cot`       AS `pagare_cot`,
    `arhus`.`ap_cotizacion`.`not_cliente_cot`  AS `not_cliente_cot`,
    `arhus`.`ap_cotizacion`.`fecha_not_cot`    AS `fecha_not_cot`
  from (`arhus`.`ap_estado_interno`
    join (`arhus`.`siax_campana`
      join (`arhus`.`ap_tipo_cliente`
        join (`arhus`.`ap_forma_pago`
          join `arhus`.`ap_cotizacion`
            on ((`arhus`.`ap_forma_pago`.`Id_forma_ap` = `arhus`.`ap_cotizacion`.`forma_pago_cot`)))
          on ((`arhus`.`ap_tipo_cliente`.`id_tipo_cliente` = `arhus`.`ap_cotizacion`.`tipo_cliente_cot`)))
        on ((`arhus`.`siax_campana`.`id_campana` = `arhus`.`ap_cotizacion`.`campana_cot`)))
      on ((`arhus`.`ap_estado_interno`.`id_estado_interno` = `arhus`.`ap_cotizacion`.`estado_cot`)));

