create view vista_solicitud as
  select
    `arhus`.`ap_solicitud`.`id_sol`                       AS `id_sol`,
    `arhus`.`siax_localidad`.`nombre_loc`                 AS `nombre_loc`,
    `arhus`.`siax_sectores`.`nombre_sec`                  AS `nombre_sec`,
    `arhus`.`ap_terceros`.`nombre_tercero`                AS `nombre_tercero`,
    `arhus`.`ap_asignacion`.`tipo_asignacion`             AS `tipo_asignacion`,
    `arhus`.`ap_estado_preventa`.`nombre_estado_preventa` AS `nombre_estado_preventa`,
    `arhus`.`ap_solicitud`.`poliza_sol`                   AS `poliza_sol`,
    `arhus`.`ap_solicitud`.`demanda_sol`                  AS `demanda_sol`,
    `arhus`.`ap_solicitud`.`cedula_sol`                   AS `cedula_sol`,
    `arhus`.`ap_solicitud`.`nombre_sol`                   AS `nombre_sol`,
    `arhus`.`ap_solicitud`.`direccion_pol_sol`            AS `direccion_pol_sol`,
    `arhus`.`ap_solicitud`.`direccion_nueva_sol`          AS `direccion_nueva_sol`,
    `arhus`.`ap_solicitud`.`telefono1_sol`                AS `telefono1_sol`,
    `arhus`.`ap_solicitud`.`telefono2_sol`                AS `telefono2_sol`,
    `arhus`.`ap_solicitud`.`celular_sol`                  AS `celular_sol`,
    `arhus`.`ap_solicitud`.`email_sol`                    AS `email_sol`,
    `arhus`.`ap_solicitud`.`servicio_sol`                 AS `servicio_sol`,
    `arhus`.`ap_solicitud`.`obs_sol`                      AS `obs_sol`,
    `arhus`.`ap_solicitud`.`fecha_prevista_sol`           AS `fecha_prevista_sol`,
    `arhus`.`ap_solicitud`.`fecha_visita_comerc_sol`      AS `fecha_visita_comerc_sol`
  from (`arhus`.`siax_localidad`
    join (`arhus`.`siax_sectores`
      join (`arhus`.`ap_terceros`
        join (`arhus`.`ap_asignacion`
          join (`arhus`.`ap_estado_preventa`
            join `arhus`.`ap_solicitud`
              on ((`arhus`.`ap_estado_preventa`.`id_estado_preventa` = `arhus`.`ap_solicitud`.`estado_sol`)))
            on ((`arhus`.`ap_asignacion`.`id_asignacion` = `arhus`.`ap_solicitud`.`asignacion_sol`)))
          on ((`arhus`.`ap_terceros`.`Id_tercero` = `arhus`.`ap_solicitud`.`asesor_sol`)))
        on ((`arhus`.`siax_sectores`.`cod_sec` = `arhus`.`ap_solicitud`.`barrio_sol`)))
      on ((`arhus`.`siax_localidad`.`id_loc` = `arhus`.`ap_solicitud`.`localidad_sol`)));

